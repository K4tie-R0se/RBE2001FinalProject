#include "robot.h"
#include "servo32u4.h"
#include "BlueMotor.h"

Servo32U4Pin5 elbowServo;  // define the servos 
Servo32U4Pin12 wristServo;
BlueMotor motor;
int currentStatus = 0;  // number to keep track of current arm position 
int motorTol = 5;


// list of points to move to
    //***THESE WILL NEED TO BE CHANGED TO BE ACCURATE ***//

    //all motor positions should be good

    int elbowPos0 = 2500;  //initial to pick up first cube questionable 
    int wristPos0 = 2000;  // should be good 
    int motorPos0 = -145;  // should be good DONE 

    int elbowPos1 = 2500; //keep servos and move arm back 
    int wristPos1 = 2000; // these should be same as pickup 
    int motorPos1 = -40; //should be good DONE 

    int elbowPos2 = 2050;
    int wristPos2 = 1500;  //DONE 
    int motorPos2 = -70;  // arm forward to drop first cube 

    int elbowPos3 = 2500; // back arm up again  DONE 
    int wristPos3 = 1500; // keep these same as drop off 
    int motorPos3 = -40;

    int elbowPos4 = 1750; // go back in to pickup second cube DONE
    int wristPos4 = 2200; // should be good 
    int motorPos4 = -70;

    int elbowPos5 = 2200; // back arm out again DONE
    int wristPos5 = 1500; // should be good 
    int motorPos5 = -50;

    int elbowPos6 = 1600; // go back in to dropoff second cube 
    int wristPos6 = 1500; // should be good 
    int motorPos6 = -75;

    int elbowPos7 = 2500; // resting position for driving 
    int wristPos7 = 2000; // should be good 
    int motorPos7 = -15;

void Robot::InitializeRobot(void)
{

    chassis.InititalizeChassis();
    //initialize all servos 
    elbowServo.attach();
    delay(100);
    elbowServo.setMinMaxMicroseconds(0,2500);
    wristServo.attach();
    delay(100);
    wristServo.setMinMaxMicroseconds(0,2500);

    motor.setup();
    motor.reset();
    
    delay(100);

    
    //pinMode(12, INPUT_PULLUP);
    /**
     * TODO: Set pin 13 HIGH when navigating and LOW when destination is reached.
     * Need to set as OUTPUT here.
     */
}

void Robot::EnterIdleState(void)
{
    chassis.Stop();

    Serial.println("-> IDLE");
    robotState = ROBOT_IDLE;
}


void moveThings(int curWrist, int curElbow, int curmotor, int wristPose, int elbowPose, int motorPose, int nextWrist, int nextElbow, int nextMotor){
        wristServo.setTargetPos(curWrist);
        elbowServo.setTargetPos(curElbow);
        motor.setTarget(curmotor);
        if ((abs(elbowPose - curElbow) <= 40)&&(abs(wristPose - curWrist) <= 40) && (abs(motorPose - curmotor) <= motorTol)){
            elbowServo.setTargetPos(nextElbow);
            wristServo.setTargetPos(nextWrist);
            motor.setTarget(nextMotor);
            currentStatus++;
        }
}

// function to move the arm 
void Robot::MoveArm(){
    

    //Serial.println("updating");
    int elbowPos; //get current position of elbow and wrist 
    elbowPos = elbowServo.currentPose();
    int wristPos;
    wristPos = wristServo.currentPose();
    Serial.println(elbowPos);  // print the current elbow position for debugging 

    int motorPos;
    motorPos = motor.getPosition();
    delay(50);  // ***DELAY MADE EVERYTHING WORK DON'T REMOVE***//

    if(currentStatus == 0){ //for each status increment 
        moveThings(wristPos0,elbowPos0,motorPos0,wristPos,elbowPos,motorPos,wristPos1,elbowPos1,motorPos1);
    }else if(currentStatus == 1){ //repeat for rest of statuses 
        moveThings(wristPos1,elbowPos1,motorPos1,wristPos,elbowPos,motorPos,wristPos2,elbowPos2,motorPos2);
    }else if(currentStatus == 2){ 
        moveThings(wristPos2,elbowPos2,motorPos2,wristPos,elbowPos,motorPos,wristPos3,elbowPos3,motorPos3);
    }else if(currentStatus == 3){ 
        moveThings(wristPos3,elbowPos3,motorPos3,wristPos,elbowPos,motorPos,wristPos4,elbowPos4,motorPos4);
    }else if(currentStatus == 4){ 
        moveThings(wristPos4,elbowPos4,motorPos4,wristPos,elbowPos,motorPos,wristPos5,elbowPos5,motorPos5);
    }else if(currentStatus == 5){ 
        moveThings(wristPos5,elbowPos5,motorPos5,wristPos,elbowPos,motorPos,wristPos6,elbowPos6,motorPos6);
    }else if(currentStatus == 6){ 
        moveThings(wristPos6,elbowPos6,motorPos6,wristPos,elbowPos,motorPos,wristPos7,elbowPos7,motorPos7);
    }else if(currentStatus == 7){ 
        moveThings(wristPos7,elbowPos7,motorPos7,wristPos,elbowPos,motorPos,wristPos7,elbowPos7,motorPos7);
    }
}




/**
 * The main loop for your robot. Process both synchronous events (motor control),
 * and asynchronous events (distance readings, etc.).
*/
void Robot::RobotLoop(void) 
{
     /**
     * Run the chassis loop, which handles low-level control.
     */

    //Serial.println("loop is running");

    wristServo.update();  //update servos 
    elbowServo.update();  // updating before setting target because I was told to

    motor.updatePos();
    //motor.setEffort(-400);

    //elbowServo.setTargetPos(1500);
    //wristServo.setTargetPos(2000);
    //motor.setTarget(-45);
    //delay(50);
    MoveArm();  // move the arm in every robot loop 

    
    //Serial.println(abs(motor.getTarget() - motor.getPosition()));
    Serial.println(currentStatus);

    Twist velocity;
    if((chassis.ChassisLoop(velocity)) &&(currentStatus == 8))
    {
        // We do FK regardless of state
        UpdatePose(velocity);

        /**
         * Here, we break with tradition and only call these functions if we're in the 
         * DRIVE_TO_POINT state. CheckReachedDestination() is expensive, so we don't want
         * to do all the maths when we don't need to.
         * 
         * While we're at it, we'll toss DriveToPoint() in, as well.
         */ 
        if(robotState == ROBOT_DRIVE_TO_POINT)
        {
            DriveToPoint();
            if(CheckReachedDestination()) HandleDestination();
        }
    }
}

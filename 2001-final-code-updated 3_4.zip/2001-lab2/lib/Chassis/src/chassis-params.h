/**
 * TODO: Adjust these to get good FK updates. They're not horrible, but neither are they good.
 */

const float ROBOT_RADIUS = 7.0;
const float LEFT_TICKS_PER_CM = 60.0;
const float RIGHT_TICKS_PER_CM = 60.0;

#include <Arduino.h>
#include <BlueMotor.h>

long oldValue = 0;
long newValue;
volatile long count = 0;
unsigned time = 0;


const int ENCA = 0;
const int ENCB = 1;

int targetPos = 0;


BlueMotor::BlueMotor()

{
}

void BlueMotor::setup()
{
    pinMode(PWMOutPin, OUTPUT);
    pinMode(AIN2, OUTPUT);
    pinMode(AIN1, OUTPUT);
    pinMode(ENCA, INPUT);
    pinMode(ENCB, INPUT);
    TCCR1A = 0xA8; //0b10101000; //gcl: added OCR1C for adding a third PWM on pin 11
    TCCR1B = 0x11; //0b00010001;
    ICR1 = 400;
    OCR1C = 0;

    attachInterrupt(digitalPinToInterrupt(ENCA), enca, CHANGE);
    attachInterrupt(digitalPinToInterrupt(ENCB), encb, CHANGE);
    reset();
}

long BlueMotor::getPosition()
{
    long tempCount = 0;
    noInterrupts();
    tempCount = count;
    interrupts();
    return tempCount;
}

void BlueMotor::reset()
{
    noInterrupts();
    count = 0;
    interrupts();
}


void BlueMotor::enca()
{
    int aState = digitalRead(ENCA);
    int bState = digitalRead(ENCB);
    if(bState == aState){
        count--;
    }else{
        count++;
    }
}

void BlueMotor::encb()
{
    int aState = digitalRead(ENCA);
    int bState = digitalRead(ENCB);
    if(bState == aState){
        count++;
    }else{
        count--;
    }

}



void BlueMotor::setEffort(int effort)
{
    if (effort < 0)
    {
        setEffort(-effort, true);
    }
    else
    {
        setEffort(effort, false);
    }
}


void BlueMotor::setEffort(int effort, bool clockwise)
{
    if (clockwise)
    {
        digitalWrite(AIN1, HIGH);
        digitalWrite(AIN2, LOW);
    }
    else
    {
        digitalWrite(AIN1, LOW);
        digitalWrite(AIN2, HIGH);
    }
    OCR1C = constrain(effort, 0, 400);
}

void BlueMotor::moveTo(long target)  //Move to this encoder position within the specified
{                                    //tolerance in the header file using proportional control
                                     //then stop
    
    setEffort(0);
}


void BlueMotor::setTarget(int target){
    targetPos = target;

    setEffort(target);

}

void BlueMotor::updatePos(){
    int currentPos = count;
    if(targetPos == currentPos) {
        setEffort(0);
        
        } // no need to update

        else if(abs(targetPos - currentPos) <= 10){
            //Serial.print("");
            setEffort(0);
        }
        else if(targetPos > currentPos) {
            //Serial.println("set positive");
            setEffort(400);
        }
        else if(targetPos < currentPos){
            //Serial.println("set negative");
            setEffort(-400);
        }
        // while(abs(targetPos - currentPos) >= 5){
        //     if(targetPos > currentPos) {
        //         setEffort(-200);
        //     }
        //     else if(targetPos < currentPos){
        //         setEffort(200);
        //     }
        //     currentPos = getPosition();
        // }
}

int BlueMotor::getTarget(){
    return targetPos;
}

#include "robot.h"
#include "servo32u4.h"
#include "BlueMotor.h"

Servo32U4Pin5 elbowServo;  // define the servos 
Servo32U4Pin12 wristServo;
BlueMotor motor;
int currentStatus = 0;  // number to keep track of current arm position 


// list of points to move to
    //***THESE WILL NEED TO BE CHANGED TO BE ACCURATE ***//

    //all motor positions should be good

    int elbowPos0 = 2000;  //initial to pick up first cube questionable 
    int wristPos0 = 2000;  // should be good 
    int motorPos0 = -160;  // should be good 

    int elbowPos1 = 2000; //keep servos and move arm back 
    int wristPos1 = 2000; // these should be same as pickup 
    int motorPos1 = -45; //should be good 

    int elbowPos2 = 1500;
    int wristPos2 = 600;
    int motorPos2 = -90;  // arm forward to drop first cube 

    int elbowPos3 = 2000; // back arm up again 
    int wristPos3 = 600; // keep these same as drop off 
    int motorPos3 = -45;

    int elbowPos4 = 2000; // go back in to pickup second cube 
    int wristPos4 = 500; // should be good 
    int motorPos4 = -90;

    int elbowPos5 = 2000; // back arm out again 
    int wristPos5 = 600; // should be good 
    int motorPos5 = -45;

    int elbowPos6 = 2000; // go back in to dropoff second cube 
    int wristPos6 = 300; // should be good 
    int motorPos6 = -110;

    int elbowPos7 = 2000; // resting position for driving 
    int wristPos7 = 2000; // should be good 
    int motorPos7 = -10;

void Robot::InitializeRobot(void)
{

    chassis.InititalizeChassis();
    //initialize all servos 
    elbowServo.attach();
    delay(100);
    elbowServo.setMinMaxMicroseconds(0,2000);
    wristServo.attach();
    delay(100);
    wristServo.setMinMaxMicroseconds(0,2000);

    motor.setup();
    motor.reset();
    
    delay(100);

    
    //pinMode(12, INPUT_PULLUP);
    /**
     * TODO: Set pin 13 HIGH when navigating and LOW when destination is reached.
     * Need to set as OUTPUT here.
     */
}

void Robot::EnterIdleState(void)
{
    chassis.Stop();

    Serial.println("-> IDLE");
    robotState = ROBOT_IDLE;
}


// function to move the arm 
void Robot::MoveArm(){
    

    //Serial.println("updating");
    int elbowPos; //get current position of elbow and wrist 
    elbowPos = elbowServo.currentPose();
    int wristPos;
    wristPos = wristServo.currentPose();
    Serial.println(elbowPos);  // print the current elbow position for debugging 

    int motorPos;
    motorPos = motor.getPosition();
    delay(50);  // ***DELAY MADE EVERYTHING WORK DON'T REMOVE***//

    if(currentStatus == 0){ //for each status increment 
        wristServo.setTargetPos(wristPos0);  // set the corrent target position 
        elbowServo.setTargetPos(elbowPos0);
        motor.setTarget(motorPos0);

        // if it's at the target position within servo errors
        if ((abs(elbowPos - elbowPos0) <= 40)&&(abs(wristPos - wristPos0) <= 40) && (abs(motorPos - motorPos0) <= 10)){
            elbowServo.setTargetPos(elbowPos1);  // update targets 
            wristServo.setTargetPos(wristPos1);
            motor.setTarget(motorPos1);
            currentStatus++;  // incremenmt status 
            delay(1000);
        }
    }else if(currentStatus == 1){ //repeat for rest of statuses 
        wristServo.setTargetPos(wristPos1);
        elbowServo.setTargetPos(elbowPos1);
        motor.setTarget(motorPos1);
        if ((abs(elbowPos - elbowPos1) <= 40)&&(abs(wristPos - wristPos1) <= 40) && (abs(motorPos - motorPos1) <= 10)){
            elbowServo.setTargetPos(elbowPos2);
            wristServo.setTargetPos(wristPos2);
            motor.setTarget(motorPos2);
            currentStatus++;
            delay(1000);
        }
    }else if(currentStatus == 2){ 
        wristServo.setTargetPos(wristPos2);
        elbowServo.setTargetPos(elbowPos2);
        motor.setTarget(motorPos2);
        if ((abs(elbowPos - elbowPos2) <= 40)&&(abs(wristPos - wristPos2) <= 40) && (abs(motorPos - motorPos2) <= 10)){
            elbowServo.setTargetPos(elbowPos3);
            wristServo.setTargetPos(wristPos3);
            motor.setTarget(motorPos3);
            currentStatus++;
            delay(1000);
        }
    }else if(currentStatus == 3){ 
        wristServo.setTargetPos(wristPos3);
        elbowServo.setTargetPos(elbowPos3);
        motor.setTarget(motorPos3);
        if ((abs(elbowPos - elbowPos3) <= 40)&&(abs(wristPos - wristPos3) <= 40) && (abs(motorPos - motorPos3) <= 10)){
            elbowServo.setTargetPos(elbowPos4);
            wristServo.setTargetPos(wristPos4);
            motor.setTarget(motorPos4);
            currentStatus++;
            delay(1000);
        }
    }else if(currentStatus == 4){ 
        wristServo.setTargetPos(wristPos4);
        elbowServo.setTargetPos(elbowPos4);
        motor.setTarget(motorPos4);
        if ((abs(elbowPos - elbowPos4) <= 40)&&(abs(wristPos - wristPos4) <= 40) && (abs(motorPos - motorPos4) <= 10)){
            elbowServo.setTargetPos(elbowPos5);
            wristServo.setTargetPos(wristPos5);
            motor.setTarget(motorPos5);
            currentStatus++;
            delay(1000);
        }
    }else if(currentStatus == 5){ 
        wristServo.setTargetPos(wristPos5);
        elbowServo.setTargetPos(elbowPos5);
        motor.setTarget(motorPos5);
        if ((abs(elbowPos - elbowPos5) <= 40)&&(abs(wristPos - wristPos5) <= 40) && (abs(motorPos - motorPos5) <= 10)){
            elbowServo.setTargetPos(elbowPos6);
            wristServo.setTargetPos(wristPos6);
            motor.setTarget(motorPos6);
            currentStatus++;
            delay(1000);
        }
    }else if(currentStatus == 6){ 
        wristServo.setTargetPos(wristPos6);
        elbowServo.setTargetPos(elbowPos6);
        motor.setTarget(motorPos6);
        if ((abs(elbowPos - elbowPos6) <= 40)&&(abs(wristPos - wristPos6) <= 40) && (abs(motorPos - motorPos6) <= 10)){
            elbowServo.setTargetPos(elbowPos7);
            wristServo.setTargetPos(wristPos7);
            motor.setTarget(motorPos7);
            currentStatus++;
            delay(1000);
        }
    }else if(currentStatus == 7){ 
        wristServo.setTargetPos(wristPos7);
        elbowServo.setTargetPos(elbowPos7);
        motor.setTarget(motorPos7);
        if ((abs(elbowPos - elbowPos7) <= 40)&&(abs(wristPos - wristPos7) <= 40) && (abs(motorPos - motorPos7) <= 10)){
            elbowServo.setTargetPos(elbowPos7);
            wristServo.setTargetPos(wristPos7);
            motor.setTarget(motorPos7);
            currentStatus++;
        }
    }
}




/**
 * The main loop for your robot. Process both synchronous events (motor control),
 * and asynchronous events (distance readings, etc.).
*/
void Robot::RobotLoop(void) 
{
     /**
     * Run the chassis loop, which handles low-level control.
     */

    //Serial.println("loop is running");

    wristServo.update();  //update servos 
    elbowServo.update();  // updating before setting target because I was told to

    motor.updatePos();
    //motor.setEffort(-400);

    //elbowServo.setTargetPos(1500);
    //wristServo.setTargetPos(2000);
    //motor.setTarget(-45);
    //delay(50);
    MoveArm();  // move the arm in every robot loop 

    
    //Serial.println(abs(motor.getTarget() - motor.getPosition()));
    Serial.println(currentStatus);

    Twist velocity;
    if(chassis.ChassisLoop(velocity))
    {
        // We do FK regardless of state
        UpdatePose(velocity);

        /**
         * Here, we break with tradition and only call these functions if we're in the 
         * DRIVE_TO_POINT state. CheckReachedDestination() is expensive, so we don't want
         * to do all the maths when we don't need to.
         * 
         * While we're at it, we'll toss DriveToPoint() in, as well.
         */ 
        if(robotState == ROBOT_DRIVE_TO_POINT)
        {
            DriveToPoint();
            if(CheckReachedDestination()) HandleDestination();
        }
    }
}

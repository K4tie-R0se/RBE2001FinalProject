
#pragma once


class BlueMotor
{
public:
    BlueMotor();
    void setEffort(int effort);
    void moveTo(long position);
    long getPosition();
    void reset();
    void setup();
    void setTarget(int target);
    void updatePos();
    int getTarget();

private:
    void setEffort(int effort, bool clockwise);
    static void enca();
    static void encb();
    const int tolerance = 3;
    const int PWMOutPin = 11;
    const int AIN2 = 4;
    const int AIN1 = 7;
};
#pragma once
#include <Arduino.h>

struct Pose {
    float x = 0.0f;      // cm
    float y = 0.0f;      // cm
    float theta = 0.0f;  // rad
    Pose() = default;
    Pose(float x_, float y_, float t_) : x(x_), y(y_), theta(t_) {}
};

struct Twist {
    float u = 0.0f;     // cm/s (forward)
    float v = 0.0f;     // cm/s (lateral, unused)
    float omega = 0.0f; // rad/s
    Twist() = default;
    Twist(float u_, float v_, float w_) : u(u_), v(v_), omega(w_) {}
};

// Optional Teleplot-style printer (safe no-op if Serial not ready)
inline void TeleplotPrint(const char* name, float value) {
    Serial.print(name);
    Serial.print(':');
    Serial.println(value, 6);
}

#pragma once
#include <stdint.h>
#include <stdlib.h>

struct PControllerConfig {
    float   kp        = 1.0f;
    int16_t minEffort = 0;
    int16_t maxEffort = 400;
    int16_t tolerance = 0;
};

inline bool pc_atTarget(long error, const PControllerConfig& cfg) {
    return labs(error) <= cfg.tolerance;
}

inline int16_t pc_computeEffort(long error, const PControllerConfig& cfg) {
    if (pc_atTarget(error, cfg)) { return 0; }

    long absErr = labs(error);
    float effortF = cfg.kp * (float)absErr;
    int16_t effort = (int16_t)effortF;

    if (effort < cfg.minEffort) effort = cfg.minEffort;
    if (effort > cfg.maxEffort) effort = cfg.maxEffort;

    return (error >= 0) ? effort : (int16_t)(-effort);
}

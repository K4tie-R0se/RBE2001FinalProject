#pragma once
#include <stdint.h>

namespace config {

// -------------------- Arm geometry (informational) --------------------
constexpr float L1_IN = 7.0f;
constexpr float L2_IN = 7.5f;
constexpr float L1_CM = 17.78f;   // 7.0 * 2.54
constexpr float L2_CM = 19.05f;   // 7.5 * 2.54
constexpr float MAX_REACH_CM = L1_CM + L2_CM; // ~36.83 cm

// -------------------- BlueMotor (J1) control --------------------
// If you know the true CPR and gear ratio, fill these in.
// They are not required if you operate purely in "encoder counts".
constexpr int32_t J1_ENCODER_CPR = 270;     // from your Lab1 sketch; VERIFY (else set -1)
constexpr float   J1_GEAR_RATIO  = -1.0f;   // UNSPECIFIED

constexpr int16_t J1_MAX_EFFORT = 400;      // matches OCR1 top in many Pololu motor configs
constexpr int16_t J1_MIN_EFFORT = 60;       // static friction compensation
constexpr float   J1_KP         = 2.0f;     // effort per count
constexpr int16_t J1_TOLERANCE_COUNTS = 3;

// Calibrate these by moving to poses and recording encoder counts.
constexpr int32_t J1_HOME_COUNTS         = 0;
constexpr int32_t J1_GROUND_PICK_COUNTS  = -300;
constexpr int32_t J1_BOTTOM_PLACE_COUNTS = 200;
constexpr int32_t J1_TOP_PICK_COUNTS     = 450;
constexpr int32_t J1_TOP_PLACE_COUNTS    = 500;
constexpr int32_t J1_CARRY_COUNTS        = 100;

// -------------------- BlueMotor (J1) pins --------------------
// NOTE: Pololu documents pin 11 is free if you are not using the LCD,
// and it can be PWM. Verify your wiring before changing. citeturn5search36
constexpr uint8_t J1_PIN_PWM  = 11;
constexpr uint8_t J1_PIN_AIN1 = 13;
constexpr uint8_t J1_PIN_AIN2 = 4;
constexpr uint8_t J1_PIN_STBY = 12;
constexpr uint8_t J1_PIN_ENCA = 0;
constexpr uint8_t J1_PIN_ENCB = 1;

// -------------------- FS90R servo pins (J2–J5) --------------------
constexpr uint8_t PIN_J2_ELBOW_SERVO   = 5;
constexpr uint8_t PIN_J3_WRIST_SERVO   = 6; // If buzzer is used, avoid pin 6 or cut jumper.
constexpr uint8_t PIN_J4_RACK_SERVO    = 7;
constexpr uint8_t PIN_J5_GRIPPER_SERVO = 8;

// -------------------- Optional limit switches --------------------
constexpr bool USE_LIMIT_SWITCHES = false;
constexpr uint8_t PIN_RACK_RETRACT_SWITCH   = 255; // UNSPECIFIED (255 disables)
constexpr uint8_t PIN_GRIPPER_OPEN_SWITCH   = 255; // UNSPECIFIED (255 disables)

// -------------------- FS90R pulses (microseconds) --------------------
// FS90R stop is near 1500us and can be trimmed with the built-in potentiometer. citeturn0search4turn0search7
constexpr uint16_t FS90R_STOP_US    = 1500;
constexpr uint16_t FS90R_SLOW_CW_US  = 1300;
constexpr uint16_t FS90R_SLOW_CCW_US = 1700;

// Direction mapping: swap CW/CCW if your mechanism goes the wrong way.
constexpr uint16_t J2_ELBOW_DOWN_US    = FS90R_SLOW_CCW_US; // UNSPECIFIED direction
constexpr uint16_t J2_ELBOW_UP_US      = FS90R_SLOW_CW_US;

constexpr uint16_t J3_WRIST_UP_US      = FS90R_SLOW_CCW_US; // UNSPECIFIED direction
constexpr uint16_t J3_WRIST_DOWN_US    = FS90R_SLOW_CW_US;

constexpr uint16_t J4_RACK_EXTEND_US   = FS90R_SLOW_CCW_US; // UNSPECIFIED direction
constexpr uint16_t J4_RACK_RETRACT_US  = FS90R_SLOW_CW_US;

constexpr uint16_t J5_GRIPPER_CLOSE_US = FS90R_SLOW_CCW_US; // UNSPECIFIED direction
constexpr uint16_t J5_GRIPPER_OPEN_US  = FS90R_SLOW_CW_US;

// -------------------- Timed primitives (ms) --------------------
// All must be calibrated on your actual mechanism.
constexpr uint16_t T_HOME_ELBOW_MS   = 600;
constexpr uint16_t T_HOME_WRIST_MS   = 400;
constexpr uint16_t T_HOME_RACK_MS    = 800;
constexpr uint16_t T_HOME_GRIPPER_MS = 500;

constexpr uint16_t T_ELBOW_LOWER_TO_GROUND_MS = 700;
constexpr uint16_t T_ELBOW_LIFT_MS            = 700;

constexpr uint16_t T_RACK_EXTEND_TO_CUBE_MS   = 500;
constexpr uint16_t T_RACK_RETRACT_MS          = 600;

constexpr uint16_t T_GRIPPER_CLOSE_MS         = 450;
constexpr uint16_t T_GRIPPER_OPEN_MS          = 450;

constexpr uint16_t T_ELBOW_LOWER_TO_SHELF_MS  = 450;
constexpr uint16_t T_WRIST_ADJUST_FOR_TOP_MS  = 300;

// -------------------- Chassis navigation/odometry --------------------
constexpr uint16_t CHASSIS_CONTROL_MS   = 20;
constexpr float    DRIVE_AWAY_DISTANCE_CM = 60.0f; // UNSPECIFIED adjust in lab
constexpr float    DEST_TOLERANCE_CM      = 2.0f;

constexpr float NAV_KP_DIST    = 3.0f;
constexpr float NAV_KP_HEADING = 8.0f;      // motor units per radian
constexpr float NAV_MAX_SPEED  = 200.0f;    // within -300..300 typical range citeturn6search0
constexpr float NAV_MAX_TURN   = 150.0f;

// -------------------- Safety --------------------
constexpr uint32_t STATE_TIMEOUT_MS = 20000;

} // namespace config

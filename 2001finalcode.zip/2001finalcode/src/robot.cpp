#include "robot.h"

void Robot::InitializeRobot()
{
    Serial.begin(115200);

    chassis.InitializeChassis();
    blueMotor.setup();

    elbowServo.attach(6);
    wristServo.attach(7);
    rackServo.attach(8);
    gripperServo.attach(9);

    elbowServo.write(90);
    wristServo.write(90);
    rackServo.write(90);
    gripperServo.write(90);

    robotState = ROBOT_PICK_GROUND;
}

void Robot::RobotLoop()
{
    switch(robotState)
    {
        case ROBOT_PICK_GROUND:
            if(PickGround())
                robotState = ROBOT_PLACE_BOTTOM;
            break;

        case ROBOT_PLACE_BOTTOM:
            if(PlaceBottom())
                robotState = ROBOT_PICK_TOP;
            break;

        case ROBOT_PICK_TOP:
            if(PickTop())
                robotState = ROBOT_PLACE_TOP;
            break;

        case ROBOT_PLACE_TOP:
            if(PlaceTop())
                robotState = ROBOT_DRIVE_AWAY;
            break;

        case ROBOT_DRIVE_AWAY:
            SetDestination(currPose.x + 0.5, currPose.y);
            if(CheckReachedDestination())
                robotState = ROBOT_DONE;
            break;

        case ROBOT_DONE:
            chassis.Stop();
            break;

        default:
            break;
    }
}

bool Robot::RunServoStep(Servo &s, int speed, int duration)
{
    if(armStep == 0)
    {
        s.write(speed);
        stepStart = millis();
        armStep = 1;
        return false;
    }

    if(millis() - stepStart >= duration)
    {
        s.write(90);
        armStep = 0;
        return true;
    }

    return false;
}

bool Robot::PickGround()
{
    switch(armStep)
    {
        case 0:
            blueMotor.moveTo(-300);
            if(abs(blueMotor.getPosition() + 300) < 5)
                armStep++;
            break;

        case 1:
            if(RunServoStep(elbowServo, 170, 700))
                armStep++;
            break;

        case 2:
            if(RunServoStep(rackServo, 170, 500))
                armStep++;
            break;

        case 3:
            if(RunServoStep(gripperServo, 170, 400))
                armStep++;
            break;

        case 4:
            if(RunServoStep(rackServo, 10, 500))
                armStep++;
            break;

        case 5:
            if(RunServoStep(elbowServo, 10, 700))
            {
                armStep = 0;
                return true;
            }
            break;
    }

    return false;
}

bool Robot::PlaceBottom()
{
    switch(armStep)
    {
        case 0:
            blueMotor.moveTo(200);
            if(abs(blueMotor.getPosition() - 200) < 5)
                armStep++;
            break;

        case 1:
            if(RunServoStep(elbowServo, 170, 500))
                armStep++;
            break;

        case 2:
            if(RunServoStep(rackServo, 170, 500))
                armStep++;
            break;

        case 3:
            if(RunServoStep(gripperServo, 10, 400))
                armStep++;
            break;

        case 4:
            if(RunServoStep(rackServo, 10, 500))
            {
                armStep = 0;
                return true;
            }
            break;
    }

    return false;
}

bool Robot::PickTop()
{
    switch(armStep)
    {
        case 0:
            blueMotor.moveTo(450);
            if(abs(blueMotor.getPosition() - 450) < 5)
                armStep++;
            break;

        case 1:
            if(RunServoStep(wristServo, 170, 400))
                armStep++;
            break;

        case 2:
            if(RunServoStep(rackServo, 170, 500))
                armStep++;
            break;

        case 3:
            if(RunServoStep(gripperServo, 170, 400))
            {
                armStep = 0;
                return true;
            }
            break;
    }

    return false;
}

bool Robot::PlaceTop()
{
    switch(armStep)
    {
        case 0:
            blueMotor.moveTo(500);
            if(abs(blueMotor.getPosition() - 500) < 5)
                armStep++;
            break;

        case 1:
            if(RunServoStep(rackServo, 170, 500))
                armStep++;
            break;

        case 2:
            if(RunServoStep(gripperServo, 10, 400))
            {
                armStep = 0;
                return true;
            }
            break;
    }

    return false;
}
#pragma once

#include <Arduino.h>
#include <Servo32u4.h>
#include "chassis.h"
#include "BlueMotor.h"

struct Pose
{
    float x;
    float y;
    float theta;
};

class Robot
{
public:
    void InitializeRobot();
    void RobotLoop();

private:

    enum RobotState
    {
        ROBOT_IDLE,
        ROBOT_PICK_GROUND,
        ROBOT_PLACE_BOTTOM,
        ROBOT_PICK_TOP,
        ROBOT_PLACE_TOP,
        ROBOT_DRIVE_AWAY,
        ROBOT_DONE
    };

    RobotState robotState = ROBOT_IDLE;

    Chassis chassis;
    BlueMotor blueMotor;

    Pose currPose;
    Pose destPose;

    Servo elbowServo;
    Servo wristServo;
    Servo rackServo;
    Servo gripperServo;

    int armStep = 0;
    unsigned long stepStart = 0;

    void UpdatePose(float v, float omega);
    void SetDestination(float x, float y);
    bool CheckReachedDestination();

    bool PickGround();
    bool PlaceBottom();
    bool PickTop();
    bool PlaceTop();

    bool RunServoStep(Servo &s, int speed, int duration);
};
#include "robot.h"
#include <math.h>

float Robot::NormalizeAngle(float a) {
    while (a > PI)  a -= 2.0f * PI;
    while (a < -PI) a += 2.0f * PI;
    return a;
}

void Robot::UpdatePose(const Twist& twist) {
    float dt = chassis_.CONTROL_LOOP_PERIOD_MS / 1000.0f;

    float prevTheta = currPose_.theta;
    currPose_.theta += twist.omega * dt;

    float thetaStar = 0.5f * (prevTheta + currPose_.theta);
    currPose_.x += twist.u * dt * cos(thetaStar);
    currPose_.y += twist.u * dt * sin(thetaStar);
}

void Robot::SetDestination(const Pose& dest) {
    destPose_ = dest;
    destValid_ = true;
}

void Robot::SetDestinationRelative(float forwardCm) {
    Pose dest = currPose_;
    dest.x += forwardCm * cos(currPose_.theta);
    dest.y += forwardCm * sin(currPose_.theta);
    dest.theta = currPose_.theta;
    SetDestination(dest);
}

bool Robot::CheckReachedDestination() {
    if (!destValid_) return false;

    float dx = destPose_.x - currPose_.x;
    float dy = destPose_.y - currPose_.y;
    float dist = sqrtf(dx*dx + dy*dy);

    return dist <= config::DEST_TOLERANCE_CM;
}

void Robot::DriveToPoint() {
    if (!destValid_) {
        chassis_.Stop();
        return;
    }

    float dx = destPose_.x - currPose_.x;
    float dy = destPose_.y - currPose_.y;

    float distError = sqrtf(dx*dx + dy*dy);
    float desiredHeading = atan2f(dy, dx);
    float headingError = NormalizeAngle(desiredHeading - currPose_.theta);

    float v = config::NAV_KP_DIST * distError;
    float w = config::NAV_KP_HEADING * headingError;

    v = constrain(v, 0.0f, config::NAV_MAX_SPEED);
    w = constrain(w, -config::NAV_MAX_TURN, config::NAV_MAX_TURN);

    int16_t left  = (int16_t)constrain(v - w, -300.0f, 300.0f);
    int16_t right = (int16_t)constrain(v + w, -300.0f, 300.0f);

    chassis_.SetMotorEfforts(left, right);
}

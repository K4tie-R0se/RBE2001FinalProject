#include "robot.h"

Robot robot;

void setup()
{
    robot.InitializeRobot();
}

void loop()
{
    robot.RobotLoop();
}
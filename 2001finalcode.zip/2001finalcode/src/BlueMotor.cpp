#include <Arduino.h>
#include <avr/io.h>
#include "BlueMotor.h"
#include "config.h"

// ---- Single-motor global encoder state (ISR-friendly) ----
static volatile long g_count = 0;
static volatile uint8_t g_lastA = 0;
static volatile uint8_t g_lastB = 0;

static BlueMotorPins g_pins; // accessed by ISR

BlueMotor::BlueMotor()
: BlueMotor(BlueMotorPins{
    config::J1_PIN_PWM,
    config::J1_PIN_AIN1,
    config::J1_PIN_AIN2,
    config::J1_PIN_STBY,
    config::J1_PIN_ENCA,
    config::J1_PIN_ENCB
}) {}

BlueMotor::BlueMotor(const BlueMotorPins& pins) : pins_(pins) {
    g_pins = pins_;

    ctrl_.kp        = config::J1_KP;
    ctrl_.minEffort = config::J1_MIN_EFFORT;
    ctrl_.maxEffort = config::J1_MAX_EFFORT;
    ctrl_.tolerance = config::J1_TOLERANCE_COUNTS;
}

void BlueMotor::setup() {
    pinMode(pins_.pwm, OUTPUT);
    pinMode(pins_.ain1, OUTPUT);
    pinMode(pins_.ain2, OUTPUT);
    pinMode(pins_.stby, OUTPUT);

    digitalWrite(pins_.stby, HIGH); // enable motor driver

    pinMode(pins_.encA, INPUT_PULLUP);
    pinMode(pins_.encB, INPUT_PULLUP);

    g_lastA = digitalRead(pins_.encA);
    g_lastB = digitalRead(pins_.encB);

    // Enable PWM output on OC1C if pin is wired to Timer1C output (pin 11 on many 32U4 variants).
    // IMPORTANT: We do NOT reconfigure Timer1 mode/top here (Romi32U4Motors uses Timer1). citeturn3view0
    TCCR1A |= _BV(COM1C1);  // non-inverting PWM on OC1C
    OCR1C = 0;

    attachInterrupt(digitalPinToInterrupt(pins_.encA), isr, CHANGE);
    reset();
}

void BlueMotor::reset() {
    noInterrupts();
    g_count = 0;
    interrupts();
}

long BlueMotor::getPosition() {
    long tmp;
    noInterrupts();
    tmp = g_count;
    interrupts();
    return tmp;
}

bool BlueMotor::isAtPosition(long targetCounts) const {
    long err = targetCounts - getPosition();
    return pc_atTarget(err, ctrl_);
}

void BlueMotor::stop() {
    setEffort(0);
}

void BlueMotor::setEffort(int16_t effort) {
    bool cw = false;
    uint16_t mag = 0;

    if (effort < 0) { cw = true; mag = (uint16_t)(-effort); }
    else { cw = false; mag = (uint16_t)effort; }

    if (mag > (uint16_t)ctrl_.maxEffort) mag = (uint16_t)ctrl_.maxEffort;
    setEffortRaw(mag, cw);
}

void BlueMotor::setEffortRaw(uint16_t effort, bool clockwise) {
    if (clockwise) {
        digitalWrite(pins_.ain1, HIGH);
        digitalWrite(pins_.ain2, LOW);
    } else {
        digitalWrite(pins_.ain1, LOW);
        digitalWrite(pins_.ain2, HIGH);
    }

    // OCR1C duty cycle, assumes Timer1 top configured elsewhere (Romi motor library).
    OCR1C = effort;
}

void BlueMotor::moveTo(long targetCounts) {
    lastTarget_ = targetCounts;
    long err = targetCounts - getPosition();
    int16_t cmd = pc_computeEffort(err, ctrl_);
    setEffort(cmd);
}

void BlueMotor::isr() {
    uint8_t a = (uint8_t)digitalRead(g_pins.encA);
    uint8_t b = (uint8_t)digitalRead(g_pins.encB);

    // Simple quadrature decode: determine direction via state transitions.
    // Matches your Lab1 concept (count++ / count-- based on transitions).
    uint8_t last = (g_lastA << 1) | g_lastB;
    uint8_t now  = (a << 1) | b;

    // Gray code sequence for quadrature (00->01->11->10->00) one direction
    if ((last == 0b00 && now == 0b01) ||
        (last == 0b01 && now == 0b11) ||
        (last == 0b11 && now == 0b10) ||
        (last == 0b10 && now == 0b00)) {
        g_count++;
    } else if ((last == 0b00 && now == 0b10) ||
               (last == 0b10 && now == 0b11) ||
               (last == 0b11 && now == 0b01) ||
               (last == 0b01 && now == 0b00)) {
        g_count--;
    }

    g_lastA = a;
    g_lastB = b;
}

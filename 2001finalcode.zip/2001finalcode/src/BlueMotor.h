#pragma once
#include <Arduino.h>

struct BlueMotorPins {
    uint8_t pwm;
    uint8_t ain1;
    uint8_t ain2;
    uint8_t stby;
    uint8_t encA;
    uint8_t encB;
};

class BlueMotor {
public:
    BlueMotor();                     // uses config defaults
    explicit BlueMotor(const BlueMotorPins& pins);

    void setup();
    void reset();
    long getPosition();

    // Open-loop effort: signed, unitless "PWM" effort (clamped internally).
    void setEffort(int16_t effort);

    // Non-blocking position control: call repeatedly in your loop.
    void moveTo(long targetCounts);

    bool isAtPosition(long targetCounts) const;
    void stop();

private:
    void setEffortRaw(uint16_t effort, bool clockwise);
    static void isr();

    BlueMotorPins pins_{};

    PControllerConfig ctrl_{};
    mutable long lastTarget_ = 0;
};

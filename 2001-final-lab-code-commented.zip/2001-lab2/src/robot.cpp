#include "robot.h"
#include "servo32u4.h"

Servo32U4Pin5 elbowServo;  // define the servos 
Servo32U4Pin12 wristServo;
int currentStatus = 0;  // number to keep track of current arm position 

void Robot::InitializeRobot(void)
{
    //initialize all servos 
    elbowServo.attach();
    delay(100);
    elbowServo.setMinMaxMicroseconds(0,2000);
    Servo32U4Pin12 wristServo;
    wristServo.attach();
    delay(100);
    wristServo.setMinMaxMicroseconds(0,2000);
    


    
    chassis.InititalizeChassis();
    pinMode(12, INPUT_PULLUP);
    /**
     * TODO: Set pin 13 HIGH when navigating and LOW when destination is reached.
     * Need to set as OUTPUT here.
     */
}

void Robot::EnterIdleState(void)
{
    chassis.Stop();

    Serial.println("-> IDLE");
    robotState = ROBOT_IDLE;
}


// function to move the arm 
void Robot::MoveArm(){
    // list of points to move to
    //***THESE WILL NEED TO BE CHANGED TO BE ACCURATE ***//
    int elbowPos0 = 2000;  
    int wristPos0 = 2000;
    int elbowPos1 = 1000;
    int wristPos1 = 1000;
    int elbowPos2 = 1500;
    int wristPos2 = 1500;
    int elbowPos3 = 2000;
    int wristPos3 = 2000;

    //Serial.println("updating");
    int elbowPos; //get current position of elbow and wrist 
    elbowPos = elbowServo.currentPose();
    int wristPos;
    wristPos = wristServo.currentPose();
    Serial.println(elbowPos);  // print the current elbow position for debugging 
    delay(100);  // ***DELAY MADE EVERYTHING WORK DON'T REMOVE***//

    if(currentStatus == 0){ //for each status increment 
        wristServo.setTargetPos(wristPos0);  // set the corrent target position 
        elbowServo.setTargetPos(elbowPos0);
        // if it's at the target position within servo errors
        if ((abs(elbowPos - elbowPos0) <= 40)&&(abs(wristPos - wristPos0) <= 40)){
            elbowServo.setTargetPos(elbowPos1);  // update targets 
            wristServo.setTargetPos(wristPos1);
            currentStatus++;  // incremenmt status 
        }
    }else if(currentStatus == 1){ //repeat for rest of statuses 
        wristServo.setTargetPos(wristPos1);
        elbowServo.setTargetPos(elbowPos1);
        if ((abs(elbowPos - elbowPos1) <= 40)&&(abs(wristPos - wristPos1) <= 40)){
            elbowServo.setTargetPos(elbowPos2);
            wristServo.setTargetPos(wristPos1);
            currentStatus++;
        }
    }else if(currentStatus == 2){ 
        wristServo.setTargetPos(wristPos2);
        elbowServo.setTargetPos(elbowPos2);
        if ((abs(elbowPos - elbowPos2) <= 40)&&(abs(wristPos - 1500) <= 40)){
            elbowServo.setTargetPos(elbowPos3);
            wristServo.setTargetPos(wristPos3);
            currentStatus++;
        }
    }
}




/**
 * The main loop for your robot. Process both synchronous events (motor control),
 * and asynchronous events (distance readings, etc.).
*/
void Robot::RobotLoop(void) 
{
     /**
     * Run the chassis loop, which handles low-level control.
     */

    //Serial.println("loop is running");

    wristServo.update();  //update servos 
    elbowServo.update();  // updating before setting target because I was told to
    MoveArm();  // move the arm in every robot loop 

    Twist velocity;
    if(chassis.ChassisLoop(velocity))
    {
        // We do FK regardless of state
        UpdatePose(velocity);

        /**
         * Here, we break with tradition and only call these functions if we're in the 
         * DRIVE_TO_POINT state. CheckReachedDestination() is expensive, so we don't want
         * to do all the maths when we don't need to.
         * 
         * While we're at it, we'll toss DriveToPoint() in, as well.
         */ 
        if(robotState == ROBOT_DRIVE_TO_POINT)
        {
            DriveToPoint();
            if(CheckReachedDestination()) HandleDestination();
        }
    }
}
